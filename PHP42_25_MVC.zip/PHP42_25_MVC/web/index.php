<?php

declare(strict_types=1);

use app\controllers\RegistrationController;
use app\controllers\HomePageController;
use app\controllers\AccountController;
use app\controllers\AboutController;
use app\controllers\TranslatorController;
use app\core\Application;
use app\core\ConfigParserYAML;

const PROJECT_ROOT = __DIR__ . "/../";

require PROJECT_ROOT . "vendor/autoload.php";
ConfigParserYAML::load();

if (getenv("APP_ENV") === "dev") {
    error_reporting(E_ALL);
    ini_set("display_errors", "1");
    ini_set("log_errors", "1");
    ini_set("error_log", sprintf("%sruntime/%s", PROJECT_ROOT, getenv("APP_PHP_LOG")));
}

session_start();

$application = new Application();
$router      = $application->getRouter();

$router->setGetRoute("/", [new RegistrationController(), "getView"]);

$router->setGetRoute("/registration", [new RegistrationController(), "getView"]);
$router->setPostRoute("/registration", [new RegistrationController(), "postView"]);

$router->setGetRoute("/home", [new HomePageController(), "getView"]);

$router->setGetRoute("/account", [new AccountController(), "getView"]);
$router->setPostRoute("/account", [new AccountController(), "postView"]);

$router->setGetRoute("/about", [new AboutController(), "getView"]);

$router->setGetRoute("/translator", [new TranslatorController(), "getView"]);
$router->setPostRoute("/translator", [new TranslatorController(), "postView"]);

$router->setGetRoute("/logout", [new class {
    public function getView() {
        session_unset();
        session_destroy();
        header("Location: /registration");
        exit;
    }
}, "getView"]);

ob_start();
$application->run();
ob_flush();
