<?php

declare(strict_types=1);

namespace app\core;

class Logger
{
    private string $logFile;

    public function __construct(string $logFile)
    {
        $this->logFile = $logFile;

        $dir = dirname($this->logFile);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        if (!file_exists($this->logFile)) {
            touch($this->logFile);
        }
    }

    public function info(string $message): void
    {
        $this->writeLog('INFO', $message);
    }

    public function error(string $message): void
    {
        $this->writeLog('ERROR', $message);
    }

    private function writeLog(string $level, string $message): void
    {
        $time = date('Y-m-d H:i:s');
        $line = "[$time] [$level] $message" . PHP_EOL;
        file_put_contents($this->logFile, $line, FILE_APPEND);
    }
}
