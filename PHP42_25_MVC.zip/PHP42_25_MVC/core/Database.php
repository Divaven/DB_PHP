<?php

declare(strict_types=1);

namespace app\core;

use PDO;
use PDOException;

class Database
{
    public PDO $pdo;

    public function __construct(string $dsn, string $user, string $password)
    {
        try {
            $this->pdo = new PDO($dsn, $user, $password);

            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {

            throw new PDOException("Cannot connect to database: " . $e->getMessage());
        }
    }
}
