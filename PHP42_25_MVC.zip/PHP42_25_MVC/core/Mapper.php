<?php

declare(strict_types=1);

namespace app\core;

abstract class Mapper
{
    protected \PDO $pdo;

    public function __construct()
    {
        $this->pdo = Application::$app->getDatabase()->pdo;
    }

    protected function queryOne(string $sql, array $params, string $className)
    {
        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        return $stmt->fetchObject($className) ?: null;
    }

    protected function queryAll(string $sql, array $params, string $className): array
    {
        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_CLASS, $className);
    }

}
