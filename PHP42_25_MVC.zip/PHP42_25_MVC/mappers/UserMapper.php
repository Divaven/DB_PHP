<?php

declare(strict_types=1);

namespace app\mappers;

use app\core\Mapper;
use app\models\User;
use PDO;
use PDOException;

class UserMapper extends Mapper
{
    public function __construct()
    {
        parent::__construct();
    }

    public function createObject(array $data): User
    {
        return new User(
            null,
            (string)($data['first_name']  ?? ''),
            (string)($data['second_name'] ?? ''),
            isset($data['age']) && $data['age'] !== '' ? (int)$data['age'] : null,
            (string)($data['email'] ?? ''),
            isset($data['phone']) && $data['phone'] !== '' ? (string)$data['phone'] : null
        );
    }

    public function insert(User $user): void
    {
        $sql = "INSERT INTO users 
                    (first_name, second_name, age, email, phone)
                VALUES
                    (:first_name, :second_name, :age, :email, :phone)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':first_name',  $user->getFirstName(),  PDO::PARAM_STR);
        $stmt->bindValue(':second_name', $user->getSecondName(), PDO::PARAM_STR);
        $stmt->bindValue(':age',         $user->getAge(),         PDO::PARAM_INT);
        $stmt->bindValue(':email',       $user->getEmail(),       PDO::PARAM_STR);
        $stmt->bindValue(':phone',       $user->getPhone(),       PDO::PARAM_STR);

        $stmt->execute();

        $newId = (int)$this->pdo->lastInsertId('user_id_seq');
        $user->setId($newId);
    }

    public function findById(int $id): ?User
    {
        $sql = "SELECT * FROM users WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            return null;
        }

        $user = new User(
            (int)$row['id'],
            (string)$row['first_name'],
            (string)$row['second_name'],
            $row['age'] !== null ? (int)$row['age'] : null,
            (string)$row['email'],
            $row['phone'] !== null ? (string)$row['phone'] : null
        );
        return $user;
    }

}
