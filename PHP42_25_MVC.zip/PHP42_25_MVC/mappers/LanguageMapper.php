<?php

declare(strict_types=1);

namespace app\mappers;

use app\core\Mapper;
use app\models\Language;

class LanguageMapper extends Mapper
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getAll(): array
    {
        $sql = "SELECT * FROM languages ORDER BY code";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_CLASS, Language::class);
    }

}
