<?php

declare(strict_types=1);

namespace app\mappers;

use app\core\Mapper;
use app\models\Profile;
use PDO;
use PDOException;

class ProfileMapper extends Mapper
{
    public function __construct()
    {
        parent::__construct();
    }

    public function createObject(array $data): Profile
    {
        return new Profile(
            isset($data['user_id'])   ? (int)$data['user_id']   : null,
            $data['full_name']  ?? null,
            $data['birthday']   ?? null,
            $data['bio']        ?? null
        );
    }

    public function insert(Profile $profile): void
    {
        $sql = "INSERT INTO profile (user_id, full_name, birthday, bio)
                VALUES (:user_id, :full_name, :birthday, :bio)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':user_id',   $profile->getUserId(),   PDO::PARAM_INT);
        $stmt->bindValue(':full_name', $profile->getFullName(), PDO::PARAM_STR);
        $stmt->bindValue(':birthday',  $profile->getBirthday(), PDO::PARAM_STR);
        $stmt->bindValue(':bio',       $profile->getBio(),      PDO::PARAM_STR);
        $stmt->execute();
    }

    public function update(Profile $profile): void
    {
        $sql = "UPDATE profile
                SET full_name = :full_name,
                    birthday  = :birthday,
                    bio       = :bio
                WHERE user_id = :user_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':full_name', $profile->getFullName(), PDO::PARAM_STR);
        $stmt->bindValue(':birthday',  $profile->getBirthday(), PDO::PARAM_STR);
        $stmt->bindValue(':bio',       $profile->getBio(),      PDO::PARAM_STR);
        $stmt->bindValue(':user_id',   $profile->getUserId(),   PDO::PARAM_INT);
        $stmt->execute();
    }

    public function deleteByUserId(int $userId): void
    {
        $sql = "DELETE FROM profile WHERE user_id = :user_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
    }

    public function findByUserId(int $userId): ?Profile
    {
        $sql = "SELECT * FROM profile WHERE user_id = :user_id LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetchObject(Profile::class);
        return $result === false ? null : $result;
    }
}
