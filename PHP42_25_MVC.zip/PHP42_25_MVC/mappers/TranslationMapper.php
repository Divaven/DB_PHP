<?php

declare(strict_types=1);

namespace app\mappers;

use app\core\Mapper;
use app\models\Translation;

class TranslationMapper extends Mapper
{
    public function __construct()
    {
        parent::__construct();
    }

    public function createObject(array $data): Translation
    {

        return new Translation(
            null,
            $data['user_id']        ?? 0,
            $data['source_text']    ?? '',
            (int)($data['source_lang_id'] ?? 0),
            (int)($data['target_lang_id'] ?? 0),
            null,
            date('Y-m-d H:i:s')
        );
    }

    public function translateAndSave(Translation $translation): string
    {
        $translated = mb_strtoupper($translation->getSourceText());

        $sql = "INSERT INTO translations 
                (user_id, source_text, source_lang_id, target_lang_id, translated_text, created_at)
                VALUES
                (:user_id, :source_text, :source_lang_id, :target_lang_id, :translated_text, :created_at)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':user_id',         $translation->getUserId());
        $stmt->bindValue(':source_text',     $translation->getSourceText());
        $stmt->bindValue(':source_lang_id',  $translation->getSourceLangId());
        $stmt->bindValue(':target_lang_id',  $translation->getTargetLangId());
        $stmt->bindValue(':translated_text', $translated);
        $stmt->bindValue(':created_at',      $translation->getCreatedAt());
        $stmt->execute();

        return $translated;
    }

    public function getByUserId(int $userId): array
    {
        $sql = "SELECT
                    t.id,
                    t.user_id,
                    t.source_text,
                    t.source_lang_id,
                    t.target_lang_id,
                    t.translated_text,
                    t.created_at,
                    l1.code AS source_code,
                    l2.code AS target_code
                FROM public.translations t
                JOIN public.languages l1 ON t.source_lang_id = l1.id
                JOIN public.languages l2 ON t.target_lang_id = l2.id
                WHERE t.user_id = :user_id
                ORDER BY t.created_at DESC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':user_id', $userId);
        $stmt->execute();

        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        $result = [];
        foreach ($rows as $row) {
            $t = new Translation(
                (int)$row['id'],
                (int)$row['user_id'],
                $row['source_text'],
                (int)$row['source_lang_id'],
                (int)$row['target_lang_id'],
                $row['translated_text'],
                $row['created_at']
            );
            $t->setSourceCode($row['source_code']);
            $t->setTargetCode($row['target_code']);
            $result[] = $t;
        }
        return $result;
    }
}
