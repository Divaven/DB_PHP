<?php
declare(strict_types=1);
namespace app\migrations;

class Migration_3 extends \app\core\Migration
{
    public function getVersion(): int
    {
        return 3;
    }

    public function up(): void
    {

        $this->database->pdo->query("
            CREATE TABLE IF NOT EXISTS languages (
                id serial PRIMARY KEY,
                code character varying(10) NOT NULL UNIQUE,  
                name character varying(100) NOT NULL          
            );"
        );


        $this->database->pdo->query("
            CREATE TABLE IF NOT EXISTS translations (
                id serial PRIMARY KEY,
                user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                source_lang_id integer NOT NULL REFERENCES languages(id) ON DELETE RESTRICT,
                target_lang_id integer NOT NULL REFERENCES languages(id) ON DELETE RESTRICT,
                source_text text NOT NULL,
                translated_text text NOT NULL,
                created_at timestamp without time zone DEFAULT now()
            );"
        );

        parent::up();
    }
}
