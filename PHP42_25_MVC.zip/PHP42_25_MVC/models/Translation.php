<?php

declare(strict_types=1);

namespace app\models;

use app\core\Model;

class Translation extends Model
{
    private int    $user_id;
    private string $source_text;
    private int    $source_lang_id;
    private int    $target_lang_id;
    private ?string $translated_text;
    private string $created_at;

    private ?string $source_code = null;
    private ?string $target_code = null;

    public function __construct(
        ?int   $id,
        int    $user_id,
        string $source_text,
        int    $source_lang_id,
        int    $target_lang_id,
        ?string $translated_text,
        string $created_at
    ) {
        parent::__construct($id);
        $this->user_id         = $user_id;
        $this->source_text     = $source_text;
        $this->source_lang_id  = $source_lang_id;
        $this->target_lang_id  = $target_lang_id;
        $this->translated_text = $translated_text;
        $this->created_at      = $created_at;
    }


    public function getUserId(): int
    {
        return $this->user_id;
    }

    public function getSourceText(): string
    {
        return $this->source_text;
    }

    public function getSourceLangId(): int
    {
        return $this->source_lang_id;
    }

    public function getTargetLangId(): int
    {
        return $this->target_lang_id;
    }

    public function getTranslatedText(): ?string
    {
        return $this->translated_text;
    }

    public function getCreatedAt(): string
    {
        return $this->created_at;
    }

    public function setSourceCode(string $code): void
    {
        $this->source_code = $code;
    }

    public function getSourceCode(): ?string
    {
        return $this->source_code;
    }

    public function setTargetCode(string $code): void
    {
        $this->target_code = $code;
    }

    public function getTargetCode(): ?string
    {
        return $this->target_code;
    }
}
