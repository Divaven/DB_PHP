<?php

declare(strict_types=1);

namespace app\models;

use app\core\Model;

class User extends Model
{
    private string   $firstName;
    private string   $secondName;
    private ?int     $age;
    private string   $email;
    private ?string  $phone;

    public function __construct(
        ?int    $id,
        string  $firstName,
        string  $secondName,
        ?int    $age,
        string  $email,
        ?string $phone
    ) {
        parent::__construct($id);
        $this->firstName  = $firstName;
        $this->secondName = $secondName;
        $this->age        = $age;
        $this->email      = $email;
        $this->phone      = $phone;
    }

    public function getFirstName(): string
    {
        return $this->firstName;
    }

    public function setFirstName(string $firstName): void
    {
        $this->firstName = $firstName;
    }

    public function getSecondName(): string
    {
        return $this->secondName;
    }

    public function setSecondName(string $secondName): void
    {
        $this->secondName = $secondName;
    }

    public function getAge(): ?int
    {
        return $this->age;
    }

    public function setAge(?int $age): void
    {
        $this->age = $age;
    }

    public function getEmail(): string
    {
        return $this->email;
    }

    public function setEmail(string $email): void
    {
        $this->email = $email;
    }

    public function getPhone(): ?string
    {
        return $this->phone;
    }

    public function setPhone(?string $phone): void
    {
        $this->phone = $phone;
    }
}
