<?php

declare(strict_types=1);

namespace app\models;

use app\core\Model;

class Profile extends Model
{
    private int $user_id;
    private ?string $full_name;
    private ?string $birthday;
    private ?string $bio;

    public function __construct(
        ?int    $user_id    = null,
        ?string $full_name  = null,
        ?string $birthday   = null,
        ?string $bio        = null
    ) {
        parent::__construct($user_id);
        $this->user_id   = $user_id ?? 0;
        $this->full_name = $full_name;
        $this->birthday  = $birthday;
        $this->bio       = $bio;
    }

    public function getUserId(): int
    {
        return $this->user_id;
    }

    public function setUserId(int $user_id): void
    {
        $this->user_id = $user_id;
    }

    public function getFullName(): ?string
    {
        return $this->full_name;
    }

    public function setFullName(?string $full_name): void
    {
        $this->full_name = $full_name;
    }

    public function getBirthday(): ?string
    {
        return $this->birthday;
    }

    public function setBirthday(?string $birthday): void
    {
        $this->birthday = $birthday;
    }

    public function getBio(): ?string
    {
        return $this->bio;
    }

    public function setBio(?string $bio): void
    {
        $this->bio = $bio;
    }
}
