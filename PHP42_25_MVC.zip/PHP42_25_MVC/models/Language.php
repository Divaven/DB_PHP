<?php

declare(strict_types=1);

namespace app\models;

use app\core\Model;

class Language extends Model
{
    private string $code;
    private string $name;

    public function __construct(?int $id = null, string $code = '', string $name = '')
    {
        parent::__construct($id);
        $this->code = $code;
        $this->name = $name;
    }

    public function getCode(): string
    {
        return $this->code;
    }

    public function getName(): string
    {
        return $this->name;
    }
}
