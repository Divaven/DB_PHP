<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Успешная регистрация</title>
    <link rel="stylesheet" href="/css/style.css">

</head>
<body>
<h1>Вы успешно зарегистрированы!</h1>
<p>Перейти на <a href="/home">домашнюю страницу</a>.</p>
</body>
</html>
