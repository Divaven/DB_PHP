<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Ошибка</title>
    <link rel="stylesheet" href="/css/style.css">

</head>
<body>
<h1>Произошла ошибка</h1>
<p>
    <?php
    if (isset($message)) {
        echo htmlspecialchars($message, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    } else {
        echo 'Неизвестная ошибка.';
    }
    ?>
</p>
<p><a href="/registration">Вернуться к регистрации</a></p>
<p><a href="/home">Вернуться на главную</a></p>
</body>
</html>
