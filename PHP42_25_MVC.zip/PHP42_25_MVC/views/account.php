<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Личный кабинет</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<nav class="navbar">
    <a href="/home">Домашняя</a>
    <a href="/about">О нас</a>
    <a href="/translator">Переводчик</a>
    <a href="/logout">Выйти</a>
</nav>

<div class="container">
    <h1>Личный кабинет пользователя <?= htmlspecialchars($user->getFirstName()) ?></h1>

    <section class="profile-section">
        <h2>Профиль</h2>
        <form action="/account" method="post">
            <div class="form-group">
                <label for="full_name">Полное имя:</label><br>
                <input
                        type="text"
                        id="full_name"
                        name="full_name"
                        value="<?= htmlspecialchars($profile->getFullName() ?? '') ?>"
                >
            </div>
            <div class="form-group">
                <label for="birthday">Дата рождения:</label><br>
                <input
                        type="date"
                        id="birthday"
                        name="birthday"
                        value="<?= htmlspecialchars($profile->getBirthday() ?? '') ?>"
                >
            </div>
            <div class="form-group">
                <label for="bio">О себе:</label><br>
                <textarea
                        id="bio"
                        name="bio"
                        rows="4"
                        cols="50"
                ><?= htmlspecialchars($profile->getBio() ?? '') ?></textarea>
            </div>
            <button type="submit" class="btn">Сохранить профиль</button>
        </form>
    </section>

    <section class="history-section">
        <h2>История переводов</h2>
        <?php if (empty($history)): ?>
            <p>Пока нет ни одного перевода.</p>
        <?php else: ?>
            <table>
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Оригинал</th>
                    <th>Перевод</th>
                    <th>Языки</th>
                    <th>Дата</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($history as $item): ?>
                    <tr>
                        <td><?= $item->getId() ?></td>
                        <td><?= nl2br(htmlspecialchars($item->getSourceText(), ENT_QUOTES)) ?></td>
                        <td><?= nl2br(htmlspecialchars($item->getTranslatedText(), ENT_QUOTES)) ?></td>
                        <td>
                            <?= htmlspecialchars($item->getSourceCode()) ?> →
                            <?= htmlspecialchars($item->getTargetCode()) ?>
                        </td>
                        <td><?= htmlspecialchars($item->getCreatedAt()) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </section>
</div>
</body>
</html>
