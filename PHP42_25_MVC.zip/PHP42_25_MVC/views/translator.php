<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Переводчик</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<h1>Онлайн-переводчик</h1>
<nav>
    <a href="/home">Домашняя</a> |
    <a href="/about">О нас</a> |
    <a href="/account">Личный кабинет</a>
</nav>
<form action="/translator" method="post">
    <div>
        <label for="source_text">Текст для перевода:</label><br>
        <textarea id="source_text" name="source_text" rows="6" cols="60" required></textarea>
    </div>
    <div>
        <label for="source_lang">Язык оригинала:</label>
        <select id="source_lang" name="source_lang" required>
            <option value="en">Английский</option>
            <option value="ru">Русский</option>
            <option value="de">Немецкий</option>
            <option value="fr">Французский</option>
            <!-- доп. варианты -->
        </select>
    </div>
    <div>
        <label for="target_lang">Язык перевода:</label>
        <select id="target_lang" name="target_lang" required>
            <option value="ru">Русский</option>
            <option value="en">Английский</option>
            <option value="de">Немецкий</option>
            <option value="fr">Французский</option>
        </select>
    </div>
    <button type="submit">Перевести</button>
</form>
</body>
</html>
