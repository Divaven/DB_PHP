<html lang="ru">
<head>
    <title>Success</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="/css/style.css">

</head>
<body>
<h1>Success!</h1>
<a href="/">На главную</a>
</body>
</html>