<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<div class="container">
    <h1>Регистрация</h1>
    <form action="/registration" method="post">
        <div class="form-group">
            <label for="first_name">Имя:</label><br>
            <input type="text" id="first_name" name="first_name" required>
        </div>
        <div class="form-group">
            <label for="second_name">Фамилия:</label><br>
            <input type="text" id="second_name" name="second_name" required>
        </div>
        <div class="form-group">
            <label for="age">Возраст:</label><br>
            <input type="number" id="age" name="age">
        </div>
        <div class="form-group">
            <label for="email">Email:</label><br>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="phone">Телефон:</label><br>
            <input type="text" id="phone" name="phone">
        </div>
        <button type="submit" class="btn">Зарегистрироваться</button>
    </form>
</div>
</body>
</html>
