<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Домашняя страница</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<nav class="navbar">
    <a href="/home">Домашняя</a>
    <a href="/account">Аккаунт</a>
    <a href="/about">О нас</a>
    <a href="/translator">Переводчик</a>
    <?php if (!empty($_SESSION['user_id'])): ?>
        <a href="/logout">Выйти</a>
    <?php else: ?>
        <a href="/registration">Регистрация</a>
    <?php endif; ?>
</nav>

<div class="container">
    <h1>
        Добро пожаловать на домашнюю страницу
        <?= isset($firstName) && $firstName !== ''
            ? ", " . htmlspecialchars($firstName)
            : ""
        ?>!
    </h1>
    <p>Здесь вы можете:</p>
    <ul>
        <li>Перейти в <a href="/account">Личный кабинет</a> и отредактировать профиль.</li>
        <li>Узнать <a href="/about">о нас</a>.</li>
        <li>Воспользоваться <a href="/translator">онлайн-переводчиком</a>.</li>
    </ul>
</div>
</body>
</html>
