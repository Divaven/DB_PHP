<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>О нас</title>
    <link rel="stylesheet" href="/css/style.css">

</head>
<body>
<h1>О нас</h1>

<p>информацию о моей компании</p>
</body>
</html>
