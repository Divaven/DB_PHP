<html lang="ru">
<head>
    <title>Форма</title>
    <meta charset="UTF-8">
</head>
<body>
<h2>Регистрация</h2>
<form action="/handle" method="post">

</form>
</body>
</html>