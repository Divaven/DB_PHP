<?php

declare(strict_types=1);

namespace app\controllers;

use app\core\Application;
use app\core\Request;
use app\mappers\UserMapper;
use app\mappers\ProfileMapper;
use app\mappers\TranslationMapper;

class AccountController
{
    private UserMapper $userMapper;
    private ProfileMapper $profileMapper;
    private TranslationMapper $translationMapper;

    public function __construct()
    {
        $this->userMapper        = new UserMapper();
        $this->profileMapper     = new ProfileMapper();
        $this->translationMapper = new TranslationMapper();
    }

    public function getView(): void
    {
        if (empty($_SESSION['user_id'])) {
            header("Location: /registration");
            exit;
        }

        $userId  = (int)$_SESSION['user_id'];
        $user    = $this->userMapper->findById($userId);
        $profile = $this->profileMapper->findByUserId($userId);
        $history = $this->translationMapper->getByUserId($userId);

        Application::$app->getRouter()->renderView('account', [
            'user'    => $user,
            'profile' => $profile,
            'history' => $history
        ]);
    }

    public function postView(Request $request): void
    {
        if (empty($_SESSION['user_id'])) {
            header("Location: /registration");
            exit;
        }

        $userId       = (int)$_SESSION['user_id'];
        $data         = $request->getBody();
        $data['user_id'] = $userId;

        try {
            $profile = $this->profileMapper->createObject($data);
            $existing = $this->profileMapper->findByUserId($userId);
            if ($existing !== null) {
                $this->profileMapper->update($profile);
            } else {
                $this->profileMapper->insert($profile);
            }
            header("Location: /account");
            exit;
        } catch (\PDOException $exception) {
            Application::$app->getLogger()->error($exception->getMessage());
            Application::$app->getRouter()->renderView('error', [
                'message' => 'Ошибка при сохранении профиля: ' . $exception->getMessage()
            ]);
        }
    }
}
