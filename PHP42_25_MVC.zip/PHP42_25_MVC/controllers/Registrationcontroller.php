<?php

declare(strict_types=1);

namespace app\controllers;

use app\core\Application;
use app\core\Request;
use app\mappers\ProfileMapper;
use app\mappers\UserMapper;
use app\models\Profile;

class RegistrationController
{
    private UserMapper $userMapper;
    private ProfileMapper $profileMapper;

    public function __construct()
    {
        $this->userMapper    = new UserMapper();
        $this->profileMapper = new ProfileMapper();
    }

    public function getView(): void
    {
        Application::$app->getRouter()->renderView('registration');
    }

    public function postView(Request $request): void
    {
        $data = $request->getBody();

        try {
            $user = $this->userMapper->createObject($data);
            $this->userMapper->insert($user);

            $newUserId = $user->getId();

            $_SESSION['user_id']    = $newUserId;
            $_SESSION['first_name'] = $user->getFirstName();

            $profile = new Profile($newUserId);
            $this->profileMapper->insert($profile);

            header("Location: /home");
            exit;
        } catch (\PDOException $exception) {
            Application::$app->getLogger()->error($exception->getMessage());
            Application::$app->getRouter()->renderView('error', [
                'message' => 'Ошибка при регистрации: ' . $exception->getMessage()
            ]);
        }
    }
}
