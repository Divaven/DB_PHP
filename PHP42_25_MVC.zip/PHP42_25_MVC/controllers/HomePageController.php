<?php

declare(strict_types=1);

namespace app\controllers;

use app\core\Application;

class HomePageController
{
    public function getView(): void
    {
        if (empty($_SESSION['user_id'])) {
            header("Location: /registration");
            exit;
        }
        $firstName = $_SESSION['first_name'] ?? '';

        Application::$app->getRouter()->renderView('home', [
            'firstName' => $firstName
        ]);
    }
}
