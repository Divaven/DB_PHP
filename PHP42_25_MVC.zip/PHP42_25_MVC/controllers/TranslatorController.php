<?php

declare(strict_types=1);

namespace app\controllers;

use app\core\Application;
use app\core\Request;
use app\mappers\TranslationMapper;
use app\models\Translation;

class TranslatorController
{
    private TranslationMapper $translationMapper;

    public function __construct()
    {
        $this->translationMapper = new TranslationMapper();
    }
    public function getView(): void
    {
        Application::$app->getRouter()->renderView('translator');
    }

    public function postView(Request $request): void
    {
        $data = $request->getBody();
        try {
            $data['user_id'] = (int)Application::$app->getRequest()->getSession('user_id');
            $obj = $this->translationMapper->createObject($data);
            $translated = $this->translationMapper->translateAndSave($obj);
            Application::$app->getRouter()->renderView('translatorResult', [
                'original'    => $obj->getSourceText(),
                'translated'  => $translated,
                'source_lang' => $obj->getSourceLang(),
                'target_lang' => $obj->getTargetLang()
            ]);
        } catch (\PDOException $exception) {
            Application::$app->getLogger()->error($exception->getMessage());
            Application::$app->getRouter()->renderView('error', [
                'message' => 'Не удалось выполнить перевод: ' . $exception->getMessage()
            ]);
        }
    }
}
